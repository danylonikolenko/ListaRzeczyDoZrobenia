function showTasks() {
    tasks.forEach(function (title) {

        addNewTask(title);

    });

}

//toggle complete
function toggleTaskComplete(task) {
    task.classList.toggle('btn-success');
}
//delete task

function deleteTask(task) {
    var liToDelete = task.closest('li');
    task.closest('ul').removeChild(liToDelete);
    console.log(task.dataset.title);
    let index = tasks.indexOf(task.dataset.title);
    tasks.splice(index);
    console.log(JSON.stringify(tasks));
    localStorage.setItem('times',JSON.stringify(tasks));
}