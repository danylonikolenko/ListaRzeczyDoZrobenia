



//
var newTaskForm = document.querySelector('.new-task-container form');
var tasksContainer = document.querySelector('.tasks-container ul');

    document.addEventListener('DOMContentLoaded',function () {
        if(JSON.parse(localStorage.getItem('times')) != null)
            tasks = JSON.parse(localStorage.getItem('times'));
        else
            tasks = [];

        console.log(tasks);
        bindAddTasksEvents();

        showTasks();
    });