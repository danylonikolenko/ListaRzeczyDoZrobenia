function addNewTask(title) {

    var taskLi = document.createElement('li');

    taskLi.classList.add('single-task');
    taskLi.innerHTML = prepareTaskHTML(title);

    //toggle and delete
    var toggleComleteBtn = taskLi.querySelector('.toggle-complete-btn');
    var deleteBtn = taskLi.querySelector('.delete-task-btn');

    toggleComleteBtn.addEventListener('click',function () {
        toggleTaskComplete(this);
    });
    deleteBtn.addEventListener('click',function () {
        deleteTask(this);
    });


    //Add task to drzewo DOM
    tasksContainer.appendChild(taskLi) ;



}

function prepareTaskHTML(title) {

return '<div class="input-group">'+
            '<span class="input-group-btn">'+
            '<button class="btn btn-default toggle-complete-btn" > <i class="fa fa-check"></i> </button>'+
        '</span>'+
        '<input type="text" class="form-control"'+
        'placeholder="Tytul" value=" '+ title+'">'+

            '<span class="input-group-btn">'+
            '<button class="btn btn-danger delete-task-btn" data-title="'+title+'"> <i class="fas fa-trash-alt"></i></button>'+
        '</span>'+
        '</div>';
}

//Add new task events
    function bindAddTasksEvents() {

    newTaskForm.addEventListener('submit', function (event) {
        event.preventDefault();
        var title = this.querySelector('input').value;
        if(title){

            addNewTask(title);
            tasks.push(title);

            localStorage.setItem('times',JSON.stringify(tasks));
            console.log(tasks);

        }

    });

}